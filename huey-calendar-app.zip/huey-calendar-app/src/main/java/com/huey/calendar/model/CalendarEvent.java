package com.huey.calendar.model;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;


public class CalendarEvent {

	private Long id;
	private Long calendarId;
	private Calendar calendar;
	private String title;
	private String location;
	private String attendeeList;
	private boolean reminderHasBeenSent;
	private LocalDateTime reminderTime;
	private LocalDateTime  eventDateAndTime;
	
	public CalendarEvent() {
		
	}
	public CalendarEvent(Calendar calendar, String title, String location, String attendeeList,
			boolean reminderHasBeenSent, LocalDateTime reminderTime, LocalDateTime eventDateAndTime) {
		super();
		this.calendar = calendar;
		this.title = title;
		this.location = location;
		this.attendeeList = attendeeList;
		this.reminderHasBeenSent = reminderHasBeenSent;
		this.reminderTime = reminderTime;
		this.eventDateAndTime = eventDateAndTime;
	}
	public Calendar getCalendar() {
		return calendar;
	}
	public void setCalendar(Calendar calendar) {
		this.calendar = calendar;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getAttendeeList() {
		return attendeeList;
	}
	public void setAttendeeList(String attendeeList) {
		this.attendeeList = attendeeList;
	}
	public boolean isReminderHasBeenSent() {
		return reminderHasBeenSent;
	}
	public void setReminderHasBeenSent(boolean reminderHasBeenSent) {
		this.reminderHasBeenSent = reminderHasBeenSent;
	}
	public LocalDateTime  getReminderTime() {
		return reminderTime;
	}
	public void setReminderTime(LocalDateTime reminderTime) {
		this.reminderTime = reminderTime;
	}
	public LocalDateTime  getEventDateAndTime() {
		return eventDateAndTime;
	}
	public void setEventDateAndTime(LocalDateTime eventDateAndTime) {
		this.eventDateAndTime = eventDateAndTime;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getCalendarId() {
		return calendarId;
	}
	public void setCalendarId(Long calendarId) {
		this.calendarId = calendarId;
	}
	
	

	
}

package com.huey.calendar.model;

public class Calendar {

	private String name;
	private String organizer;
	
	public Calendar() {
		
	}
	public Calendar(String name, String organizer) {
		super();
		this.name = name;
		this.organizer = organizer;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOrganizer() {
		return organizer;
	}
	public void setOrganizer(String organizer) {
		this.organizer = organizer;
	}
	
	
}

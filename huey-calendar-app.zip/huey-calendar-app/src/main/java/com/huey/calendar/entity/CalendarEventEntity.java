package com.huey.calendar.entity;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;

@Entity
@Table(name = "CALENDAR_EVENT")
public class CalendarEventEntity {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="calendar_event_seq_gen")
	@SequenceGenerator(name="calendar_event_seq_gen", sequenceName="calendar_event_seq")
	@Column(name = "CALENDAR_EVENT_ID")
	private Long id;
	private Long calendarId;
	private String title;
	private String location;
	private String attendeeList;
	private boolean reminderHasBeenSent;
	@JsonDeserialize(using=LocalDateTimeDeserializer.class)
	private LocalDateTime reminderTime;
	@JsonDeserialize(using=LocalDateTimeDeserializer.class)
	private LocalDateTime  eventDateAndTime;
	
	public CalendarEventEntity() {
		
	}
	public CalendarEventEntity(String title, String location, String attendeeList,
			boolean reminderHasBeenSent, LocalDateTime reminderTime, LocalDateTime eventDateAndTime) {
		super();
		this.title = title;
		this.location = location;
		this.attendeeList = attendeeList;
		this.reminderHasBeenSent = reminderHasBeenSent;
		this.reminderTime = reminderTime;
		this.eventDateAndTime = eventDateAndTime;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getAttendeeList() {
		return attendeeList;
	}
	public void setAttendeeList(String attendeeList) {
		this.attendeeList = attendeeList;
	}
	public boolean isReminderHasBeenSent() {
		return reminderHasBeenSent;
	}
	public void setReminderHasBeenSent(boolean reminderHasBeenSent) {
		this.reminderHasBeenSent = reminderHasBeenSent;
	}
	public LocalDateTime  getReminderTime() {
		return reminderTime;
	}
	public void setReminderTime(LocalDateTime reminderTime) {
		this.reminderTime = reminderTime;
	}
	public LocalDateTime  getEventDateAndTime() {
		return eventDateAndTime;
	}
	public void setEventDateAndTime(LocalDateTime eventDateAndTime) {
		this.eventDateAndTime = eventDateAndTime;
	}
	
	
	public Long getCalendarId() {
		return calendarId;
	}
	public void setCalendarId(Long calendarId) {
		this.calendarId = calendarId;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	

	
}

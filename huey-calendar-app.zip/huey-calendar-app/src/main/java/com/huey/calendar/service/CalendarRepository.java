package com.huey.calendar.service;

import org.springframework.data.repository.CrudRepository;
import com.huey.calendar.entity.CalendarEntity;

public interface CalendarRepository extends CrudRepository <CalendarEntity, Long>{

	
	
}
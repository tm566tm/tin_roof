package com.huey.calendar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;
/*
@EntityScan(
        basePackageClasses = {HueyCalendarAppApplication.class, Jsr310JpaConverters.class}
)*/

@SpringBootApplication
public class HueyCalendarAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(HueyCalendarAppApplication.class, args);
	}
}


package com.huey.calendar.service;

import org.springframework.stereotype.Service;

import com.huey.calendar.entity.CalendarEntity;
import com.huey.calendar.entity.CalendarEventEntity;
import com.huey.calendar.model.Calendar;
import com.huey.calendar.model.CalendarEvent;

@Service
public class MappingService {

	public CalendarEntity calendarToEntiry(Calendar calendar){
		
		CalendarEntity calendarEntity = new CalendarEntity(calendar.getName(),calendar.getOrganizer());		
		return calendarEntity;
	}
	
	public CalendarEventEntity calendarEventToEntiry(CalendarEvent calendarEvent , Long calendarId){
		CalendarEventEntity calendarEventEntity = new CalendarEventEntity();
		calendarEventEntity.setEventDateAndTime(calendarEvent.getEventDateAndTime());
		calendarEventEntity.setReminderTime(calendarEvent.getReminderTime());
		calendarEventEntity.setLocation(calendarEvent.getLocation());
		calendarEventEntity.setAttendeeList(calendarEvent.getAttendeeList());
		calendarEventEntity.setTitle(calendarEvent.getTitle());
		calendarEventEntity.setReminderHasBeenSent(calendarEvent.isReminderHasBeenSent());
		calendarEventEntity.setCalendarId(calendarId);
			
		return calendarEventEntity;
	}
		
	public Calendar CalendarEntityToCalendar(CalendarEntity calendarEntity){			
		return new Calendar(calendarEntity.getName(),calendarEntity.getOrganizer());
	}
	
	public CalendarEvent CalendarEvententityToCalendarEvent(CalendarEventEntity calendarEventEntity, Calendar calendar){				
		CalendarEvent calendarEvent = new CalendarEvent();
		calendarEvent.setCalendar(calendar);
		calendarEvent.setEventDateAndTime(calendarEventEntity.getEventDateAndTime());
		calendarEvent.setReminderTime(calendarEventEntity.getReminderTime());
		calendarEvent.setAttendeeList(calendarEventEntity.getAttendeeList());
		calendarEvent.setLocation(calendarEventEntity.getLocation());
		calendarEvent.setReminderHasBeenSent(calendarEventEntity.isReminderHasBeenSent());
		calendarEvent.setTitle(calendarEventEntity.getTitle());
		calendarEvent.setId(calendarEventEntity.getId());
		calendarEvent.setCalendarId(calendarEventEntity.getCalendarId());
		return calendarEvent;
	}
	
	public CalendarEvent entityToCalendarEvent(CalendarEntity calendarEntity, CalendarEventEntity calendarEventEntity){
		Calendar calendar = new Calendar();
		calendar.setName(calendarEntity.getName());
		calendar.setOrganizer(calendarEntity.getOrganizer());
		
		CalendarEvent calendarEvent = new CalendarEvent();
		calendarEvent.setCalendar(calendar);
		calendarEvent.setEventDateAndTime(calendarEventEntity.getEventDateAndTime());
		calendarEvent.setReminderTime(calendarEventEntity.getReminderTime());
		calendarEvent.setAttendeeList(calendarEventEntity.getAttendeeList());
		calendarEvent.setLocation(calendarEventEntity.getLocation());
		calendarEvent.setReminderHasBeenSent(calendarEventEntity.isReminderHasBeenSent());
		calendarEvent.setTitle(calendarEventEntity.getTitle());
		
		return calendarEvent;
	}
	
}

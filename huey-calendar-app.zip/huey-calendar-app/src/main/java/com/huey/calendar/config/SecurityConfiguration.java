package com.huey.calendar.config;

import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@EnableWebSecurity
@Configuration
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception{
		auth.inMemoryAuthentication()
				.withUser("hm2").password("{noop}pass").roles("USER").and()
				.withUser("tm3").password("{noop}pass").roles("ADMIN");


	}

	@Override
	protected void configure(HttpSecurity httpSecurity) throws Exception{
		httpSecurity
					.antMatcher("/calendarevents/authenticated")
					.authorizeRequests().anyRequest().hasRole("USER")					
					//.anyRequest().hasRole("ADMIN")
					//.permitAll()
					//.fullyAuthenticated()
					.and()
					.httpBasic();
		
		httpSecurity.csrf().disable();
	}

	
}

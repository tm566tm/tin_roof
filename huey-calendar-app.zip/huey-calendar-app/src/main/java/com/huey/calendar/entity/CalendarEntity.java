package com.huey.calendar.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "CALENDAR")
public class CalendarEntity {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="calendar_seq_gen")
	@SequenceGenerator(name="calendar_seq_gen", sequenceName="calendar_seq")
	@Column(name = "CALENDAR_EVENT_ID")
	private Long id;
	
	private String name;
	private String userName;
	
	public CalendarEntity() {
		
	}
	public CalendarEntity(String name, String userName) {
		super();
		this.name = name;
		this.userName = userName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	
	
}

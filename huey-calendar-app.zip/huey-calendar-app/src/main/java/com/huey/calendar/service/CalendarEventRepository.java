
package com.huey.calendar.service;

import org.springframework.data.repository.CrudRepository;

import com.huey.calendar.entity.CalendarEventEntity;


public interface CalendarEventRepository extends CrudRepository <CalendarEventEntity, Long>{

	
	
}
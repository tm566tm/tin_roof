package com.huey.calendar.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.huey.calendar.model.Calendar;
import com.huey.calendar.model.CalendarEvent;
import com.huey.calendar.entity.*;

@Service
public class CalendarService {

	@Autowired
	private CalendarRepository calendarRepository;
	
	@Autowired
	private CalendarEventRepository calendarEventRepository;
	
	@Autowired
	private MappingService mappingService;
	
	public CalendarEvent getCalendarEvent(Long id){
		CalendarEvent calendarEvent = new CalendarEvent();
		Calendar calendar = new Calendar();

		Optional<CalendarEventEntity> calendarEventEntity = calendarEventRepository.findById(id);
		Long calendarId = null;
		if(calendarEventEntity.isPresent()) {
			calendarId = calendarEventEntity.get().getCalendarId();
		}
		Optional<CalendarEntity> calendarEntity = calendarRepository.findById(calendarId);
		if(calendarEntity.isPresent()) {
		    calendar = mappingService.CalendarEntityToCalendar(calendarEntity.get());
		}
		if( calendarId != null){
			calendarEvent = mappingService.CalendarEvententityToCalendarEvent(calendarEventEntity.get(), calendar);
		}			
		return calendarEvent;
	}
	
	public List<CalendarEvent> getAllCalendarEvents(){
		
		List<CalendarEventEntity> calendarEventEntities = new ArrayList<>();
		calendarEventRepository.findAll().forEach(calendarEventEntities::add);
		
		List<CalendarEvent> calendarEvents = new ArrayList<>();
		
		for (int i = 0; i < calendarEventEntities.size(); i++) {
			Optional<CalendarEntity> calendarEntity = calendarRepository.findById(calendarEventEntities.get(i).getCalendarId());
			if(calendarEntity.isPresent()) {
				Calendar calendar = mappingService.CalendarEntityToCalendar(calendarEntity.get());
				CalendarEvent calendarEvent = mappingService.CalendarEvententityToCalendarEvent(calendarEventEntities.get(i), calendar);
				calendarEvents.add(calendarEvent);
			}
		}
		return calendarEvents;
	}
	public void addCalendarEvent(CalendarEvent calendarEvent) {
		Calendar calendar = calendarEvent.getCalendar();
		CalendarEntity calendarEntity = mappingService.calendarToEntiry(calendar);
		calendarRepository.save(calendarEntity);		

		CalendarEventEntity calendarEventEntity = mappingService.calendarEventToEntiry(calendarEvent,calendarEntity.getId());
		calendarEventRepository.save(calendarEventEntity);	
	}
	public void updateCalendarEvent(Long id, CalendarEvent newCalendarEvent) {
		boolean found = false;
		
		Optional<CalendarEventEntity> oldCalendarEventEntity = calendarEventRepository.findById(id);
		Long calendarId = null;
		CalendarEventEntity tempCalendarEventEntity = null;
		if(oldCalendarEventEntity.isPresent()) {
			found = true;
			calendarId = oldCalendarEventEntity.get().getCalendarId();
			tempCalendarEventEntity = oldCalendarEventEntity.get();
		}
		Optional<CalendarEntity> oldCalendarEntity = calendarRepository.findById(calendarId);
		CalendarEntity tempCalendarEntity = null;
		if(oldCalendarEntity.isPresent()) {
			tempCalendarEntity = oldCalendarEntity.get();
		}
		if(found){
			tempCalendarEntity.setName(newCalendarEvent.getCalendar().getName());
			tempCalendarEntity.setOrganizer(newCalendarEvent.getCalendar().getOrganizer());
			calendarRepository.save(tempCalendarEntity);
			
			tempCalendarEventEntity.setEventDateAndTime(newCalendarEvent.getEventDateAndTime());
			tempCalendarEventEntity.setLocation(newCalendarEvent.getLocation());
			tempCalendarEventEntity.setAttendeeList(newCalendarEvent.getAttendeeList());

			tempCalendarEventEntity.setReminderHasBeenSent(newCalendarEvent.isReminderHasBeenSent());
			tempCalendarEventEntity.setReminderTime(newCalendarEvent.getReminderTime());
			tempCalendarEventEntity.setTitle(newCalendarEvent.getTitle());
			calendarEventRepository.save(tempCalendarEventEntity);
		}
		
	}
	public void deleteCalendarEvent(Long id) {
		boolean found = false;
		Optional<CalendarEventEntity> oldCalendarEventEntity = calendarEventRepository.findById(id);
		Long calendarId = null;
		if(oldCalendarEventEntity.isPresent()) {
			found = true;
			calendarId = oldCalendarEventEntity.get().getCalendarId();
		}
		if(found){
			calendarEventRepository.deleteById(id);	
			calendarRepository.deleteById(calendarId);				
		}
			
	}
}

package com.huey.calendar.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.huey.calendar.model.CalendarEvent;
import com.huey.calendar.service.CalendarService;

@RestController
public class CalendarController {

	@Autowired
	private CalendarService calendarService;

	@RequestMapping(method=RequestMethod.DELETE, value="/calendarevents/{id}")
	public void deleteCalendarEvent(@PathVariable Long id){
		calendarService.deleteCalendarEvent(id);
	}
	
	@RequestMapping(method=RequestMethod.PUT, value="/calendarevents/{id}")
	public void updateCalendarEvent(@RequestBody CalendarEvent calendarEvent, @PathVariable Long id){
		calendarService.updateCalendarEvent(id, calendarEvent);
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/calendarevents")
	@ResponseBody
	public void addCalendarEvent(@RequestBody CalendarEvent calendarEvent){
		calendarService.addCalendarEvent(calendarEvent);
	}
	
	@RequestMapping("/calendarevents")
	public List<CalendarEvent> getAllCalendarEvents(){
		String userName = null;
		return calendarService.getAllCalendarEvents(userName);
	}
	
	@RequestMapping("/calendarevents/{id}")
	public CalendarEvent getCalendarEvent(@PathVariable Long id){
		return calendarService.getCalendarEvent(id);
	}
	
	@RequestMapping("/calendarevents/authenticated")
	public List<CalendarEvent> getAllCalendarEventsauthenticated(HttpServletRequest request, HttpServletResponse response){
		String userName = request.getUserPrincipal().getName();
		return calendarService.getAllCalendarEvents(userName);
	}
	
	@RequestMapping("/calendareventsbymonth/{month}")
	public List<CalendarEvent> getAllCalendarEventsByMonth(@PathVariable String month){
		return calendarService.getAllCalendarEventsByMonth(month);
	}
	
}